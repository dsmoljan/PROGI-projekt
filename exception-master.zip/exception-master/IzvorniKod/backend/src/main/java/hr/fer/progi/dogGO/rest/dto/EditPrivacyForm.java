package hr.fer.progi.dogGO.rest.dto;

public class EditPrivacyForm {

    boolean publicStatus;

    public boolean isPublicStatus() {
        return publicStatus;
    }

    public void setPublicStatus(boolean publicStatus) {
        this.publicStatus = publicStatus;
    }
}
