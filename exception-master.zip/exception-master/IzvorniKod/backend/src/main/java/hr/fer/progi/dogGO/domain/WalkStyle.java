package hr.fer.progi.dogGO.domain;

public enum WalkStyle {
    INDIVIDUAL, GROUP;
}
