package hr.fer.progi.dogGO.service;

public interface AdminService {
    boolean login(String username, String password);
}
