package hr.fer.progi.dogGO;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DogGoApplicationTests {

	@Test
	void addReservationTest() {

	}

}
