const { render } = require("react-dom")

function Explore () {
        return(
            <span>The dog was so scary, we called him the big bad woof.</span>
        );
}
export default Explore;